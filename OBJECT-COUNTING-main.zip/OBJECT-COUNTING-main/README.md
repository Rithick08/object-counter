# Object-Count-Detector
In this project the program will find the number of products in the given image
